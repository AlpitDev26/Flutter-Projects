import 'dart:convert';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/client.dart';
import '../models/invoice.dart';
import '../models/businessProfile.dart';

class DatabaseService {
  static final DatabaseService _instance = DatabaseService._internal();
  factory DatabaseService() => _instance;
  DatabaseService._internal();

  static Database? _database;

  Future<Database> get database async {
    return _database ??= await _initDatabase();
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'billing.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE clients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        address TEXT,
        email TEXT,
        phone TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE invoices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoiceNo TEXT,
        invoiceDate TEXT,
        client TEXT,         -- JSON encoded Client
        items TEXT,          -- JSON encoded list of InvoiceItems
        totalAmount REAL,
        amountInWords TEXT,
        bankDetails TEXT,
        paymentNote TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE business_profile (
        id INTEGER PRIMARY KEY,
        companyName TEXT,
        address TEXT,
        email TEXT,
        phone TEXT,
        pan TEXT,
        gst TEXT,
        bankName TEXT,
        accountNo TEXT,
        ifsc TEXT
      )
    ''');
  }

  // ---------------- CLIENTS ----------------

  Future<int> insertClient(Client client) async {
    final db = await database;
    return await db.insert('clients', client.toMap());
  }

  Future<List<Client>> getClients() async {
    final db = await database;
    final result = await db.query('clients');
    return result.map((e) => Client.fromMap(e)).toList();
  }

  // ---------------- INVOICES ----------------

  Future<int> insertInvoice(Invoice invoice) async {
    final db = await database;
    return await db.insert('invoices', {
      'invoiceNo': invoice.invoiceNo,
      'invoiceDate': invoice.invoiceDate,
      'client': jsonEncode(invoice.client.toMap()),
      'items': jsonEncode(invoice.items.map((e) => e.toMap()).toList()),
      'totalAmount': invoice.totalAmount,
      'amountInWords': invoice.amountInWords,
      'bankDetails': invoice.bankDetails,
      'paymentNote': invoice.paymentNote,
    });
  }

  Future<List<Invoice>> getInvoices() async {
    final db = await database;
    final result = await db.query('invoices');
    return result.map((e) => Invoice.fromMap({
      'id': e['id'],
      'invoiceNo': e['invoiceNo'],
      'invoiceDate': e['invoiceDate'],
      'client': jsonDecode(e['client'] as String),
      'items': jsonDecode(e['items'] as String),
      'totalAmount': e['totalAmount'],
      'amountInWords': e['amountInWords'],
      'bankDetails': e['bankDetails'],
      'paymentNote': e['paymentNote'],
    })).toList();
  }

  // ---------------- BUSINESS PROFILE ----------------

  Future<void> saveBusinessProfile(BusinessProfile profile) async {
    final db = await database;
    await db.insert('business_profile', profile.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<BusinessProfile?> getBusinessProfile() async {
    final db = await database;
    final result = await db.query('business_profile', limit: 1);
    if (result.isEmpty) return null;
    return BusinessProfile.fromMap(result.first);
  }
}
